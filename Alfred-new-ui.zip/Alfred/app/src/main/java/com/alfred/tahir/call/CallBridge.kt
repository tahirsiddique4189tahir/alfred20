package com.alfred.tahir.call

import android.content.Context
import android.os.Build
import android.telecom.TelecomManager
import android.util.Log
import com.alfred.tahir.AssistantService
import com.alfred.tahir.L

/** Glue between the call screening service, the overlay and the assistant's mic loop. */
object CallBridge {
    private var pendingNumber: String? = null
    private var pendingAt = 0L

    fun requestSession(number: String) {
        synchronized(this) {
            pendingNumber = number
            pendingAt = System.currentTimeMillis()
        }
    }

    /** Returns the number ("" = hidden number) of a call Alfred should handle, once. */
    fun takePending(): String? = synchronized(this) {
        val n = pendingNumber
        pendingNumber = null
        if (n != null && System.currentTimeMillis() - pendingAt < 30000) n else null
    }

    /** Answers the ringing call and asks the assistant to talk to the caller. */
    fun answer(ctx: Context, number: String) {
        val tm = ctx.getSystemService(TelecomManager::class.java)
        try {
            tm.acceptRingingCall()
        } catch (e: SecurityException) {
            Log.e("CallBridge", "ANSWER_PHONE_CALLS permission missing")
            CallOverlay.addLine("•", "ANSWER_PHONE_CALLS permission missing")
            return
        }
        CallOverlay.show(number, true)
        if (AssistantService.instance == null) {
            CallOverlay.addLine("•", "Turn Alfred ON (main screen) so it can talk to callers")
        } else {
            requestSession(number)
        }
    }

    fun reject(ctx: Context) {
        if (Build.VERSION.SDK_INT < 28) {
            CallOverlay.addLine("•", "Android 9+ is needed to hang up automatically - end the call yourself")
            return
        }
        if (Build.VERSION.SDK_INT >= 28) {
            try {
                ctx.getSystemService(TelecomManager::class.java).endCall()
            } catch (e: SecurityException) {
                CallOverlay.addLine("•", "ANSWER_PHONE_CALLS permission missing")
            }
        }
    }
}
