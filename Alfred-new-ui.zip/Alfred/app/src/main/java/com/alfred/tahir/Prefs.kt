package com.alfred.tahir

import android.content.Context
import android.content.SharedPreferences

/** All user settings live here (SharedPreferences, stored only on this phone). */
object Prefs {
    lateinit var sp: SharedPreferences
        private set

    fun init(ctx: Context) {
        if (!::sp.isInitialized) {
            sp = ctx.applicationContext.getSharedPreferences("alfred_prefs", Context.MODE_PRIVATE)
            migrateModel()
        }
    }

    /**
     * One-time migration away from model IDs that are not valid public API IDs.
     * Preserve a valid model choice; reset only known stale defaults.
     */
    private fun migrateModel() {
        if (sp.getInt("model_ver", 0) >= 1) return
        val saved = sp.getString("model", null)
        val stale = listOf(
            "gemini-3.5-flash-lite", "gemini-3.6-flash", "gemini-3.1-pro",
            "gemini-2.0-flash", "gemini-2.5-flash-lite"
        )
        val e = sp.edit()
        if (saved == null || saved in stale) e.putString("model", MODELS[0])
        e.putInt("model_ver", 1).apply()
    }

    // First item = default (fastest + cheapest). Order: fast -> smarter.
    // Keep this list to public Gemini API model IDs. Invalid IDs make every
    // request fail with 404 even when the API key is correct.
    val MODELS = listOf(
        "gemini-2.5-flash",
        "gemini-2.5-pro"
    )
    val VOICES = listOf("Charon", "Orus", "Fenrir", "Puck", "Algenib")
    const val TTS_MODEL = "gemini-2.5-flash-preview-tts"

    private fun str(k: String, d: String): String = sp.getString(k, d) ?: d

    var apiKey: String
        get() = str("api_key", "")
        set(v) { sp.edit().putString("api_key", v.trim()).apply() }

    var model: String
        get() = str("model", MODELS[0])
        set(v) { sp.edit().putString("model", v).apply() }

    fun effectiveModel(): String = model.trim().removePrefix("models/").ifBlank { MODELS[0] }

    /** auto | bn | en | hi */
    var replyLang: String
        get() = str("reply_lang", "auto")
        set(v) { sp.edit().putString("reply_lang", v).apply() }

    /** auto | en | bn | hi */
    var uiLang: String
        get() = str("ui_lang", "auto")
        set(v) { sp.edit().putString("ui_lang", v).apply() }

    /** gemini | phone */
    var voiceMode: String
        get() = str("voice_mode", "gemini")
        set(v) { sp.edit().putString("voice_mode", v).apply() }

    var voiceName: String
        get() = str("voice_name", "Charon")
        set(v) { sp.edit().putString("voice_name", v).apply() }

    /** Speaking speed: 1.0 = normal, 1.15 = brisk (default), up to 1.6 */
    var voiceSpeed: Float
        get() = sp.getFloat("voice_speed", 1.15f).coerceIn(0.8f, 1.6f)
        set(v) { sp.edit().putFloat("voice_speed", v).apply() }

    /** Alfred starts a short friendly chat by himself from time to time. */
    var proactive: Boolean
        get() = sp.getBoolean("proactive", true)
        set(v) { sp.edit().putBoolean("proactive", v).apply() }

    /** average minutes between check-ins */
    var proactiveMins: Int
        get() = sp.getInt("proactive_mins", 90)
        set(v) { sp.edit().putInt("proactive_mins", v).apply() }

    /** hour of day (0-23) when check-ins may start / stop */
    var proactiveFrom: Int
        get() = sp.getInt("proactive_from", 9)
        set(v) { sp.edit().putInt("proactive_from", v).apply() }

    var proactiveTo: Int
        get() = sp.getInt("proactive_to", 22)
        set(v) { sp.edit().putInt("proactive_to", v).apply() }

    var orbEnabled: Boolean
        get() = sp.getBoolean("orb_enabled", true)
        set(v) { sp.edit().putBoolean("orb_enabled", v).apply() }

    /** dp */
    var orbSize: Int
        get() = sp.getInt("orb_size", 68)
        set(v) { sp.edit().putInt("orb_size", v).apply() }

    var orbColor: Int
        get() = sp.getInt("orb_color", 0)
        set(v) { sp.edit().putInt("orb_color", v).apply() }

    var orbOpacity: Float
        get() = sp.getFloat("orb_opacity", 0.95f)
        set(v) { sp.edit().putFloat("orb_opacity", v).apply() }

    var orbX: Int
        get() = sp.getInt("orb_x", -1)
        set(v) { sp.edit().putInt("orb_x", v).apply() }

    var orbY: Int
        get() = sp.getInt("orb_y", -1)
        set(v) { sp.edit().putInt("orb_y", v).apply() }

    /** 0 = classic glass orb, 1.. = cute characters (see AvatarStyles) */
    var orbStyle: Int
        get() = sp.getInt("orb_style", 0)
        set(v) { sp.edit().putInt("orb_style", v).apply() }

    /** custom colour hue 0..360, or -1 = use the colour palette */
    var orbHue: Float
        get() = sp.getFloat("orb_hue", -1f)
        set(v) { sp.edit().putFloat("orb_hue", v).apply() }

    var bubbleEnabled: Boolean
        get() = sp.getBoolean("bubble_enabled", true)
        set(v) { sp.edit().putBoolean("bubble_enabled", v).apply() }

    var readNotifications: Boolean
        get() = sp.getBoolean("read_notifications", false)
        set(v) { sp.edit().putBoolean("read_notifications", v).apply() }

    /** Alfred answers calls from numbers that are not in the contacts (experimental). */
    var callAssist: Boolean
        get() = sp.getBoolean("call_assist", false)
        set(v) { sp.edit().putBoolean("call_assist", v).apply() }

    /** bn | en | hi : language of the call text shown to the owner */
    var callLang: String
        get() = str("call_lang", "bn")
        set(v) { sp.edit().putString("call_lang", v).apply() }

    /** Only the enrolled owner's voice may give commands. */
    var voiceGuard: Boolean
        get() = sp.getBoolean("voice_guard", false)
        set(v) { sp.edit().putBoolean("voice_guard", v).apply() }

    /** max cosine distance that still counts as the owner (lower = stricter) */
    var voiceThreshold: Float
        get() = sp.getFloat("voice_threshold", 0.55f)
        set(v) { sp.edit().putFloat("voice_threshold", v).apply() }

    /** owner voice fingerprint, comma separated floats ("" = not enrolled) */
    var ownerVec: String
        get() = str("owner_vec", "")
        set(v) { sp.edit().putString("owner_vec", v).apply() }

    fun ownerVector(): FloatArray? =
        ownerVec.takeIf { it.isNotBlank() }?.split(",")?.mapNotNull { it.toFloatOrNull() }?.toFloatArray()

    /** true after the user tapped "Get Started" on the welcome screen */
    var onboarded: Boolean
        get() = sp.getBoolean("onboarded", false)
        set(v) { sp.edit().putBoolean("onboarded", v).apply() }

    var ownerName: String
        get() = str("owner_name", "")
        set(v) { sp.edit().putString("owner_name", v).apply() }
}
