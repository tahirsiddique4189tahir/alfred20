package com.alfred.tahir

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

object IconHelper {

    /** Manifest er activity-alias gulor list. */
    private val allAliases = listOf(
        "MainActivityAliasDefault",
        "MainActivityAliasGalaxy",
        "MainActivityAliasCrystal",
        "MainActivityAliasLiquid",
        "MainActivityAliasNeon",
        "MainActivityAliasAurora",
        "MainActivityAliasFire",
        "MainActivityAliasIce",
        "MainActivityAliasLeaf",
        "MainActivityAliasOcean",
        "MainActivityAliasCircuit"
    )

    /** orb style id -> icon alias. null = ei style er icon nei. */
    fun aliasForStyle(style: Int): String? = when (style) {
        100 -> "MainActivityAliasGalaxy"
        101 -> "MainActivityAliasCrystal"
        102 -> "MainActivityAliasLiquid"
        103 -> "MainActivityAliasNeon"
        104 -> "MainActivityAliasAurora"
        105 -> "MainActivityAliasFire"
        106 -> "MainActivityAliasIce"
        107 -> "MainActivityAliasLeaf"
        108 -> "MainActivityAliasOcean"
        109 -> "MainActivityAliasCircuit"
        else -> null
    }

    fun changeAppIcon(context: Context, activeAliasName: String) {
        val pm = context.packageManager
        val pkg = context.packageName

        // যদি ভুল কোনো নাম আসে, তবে ডিফল্ট MainActivity সেট হবে (যাতে অ্যাপ আইকন গায়েব না হয়ে যায়)
        val targetAlias = if (activeAliasName in allAliases) activeAliasName else "MainActivityAliasDefault"

        allAliases.forEach { alias ->
            val state = if (alias == targetAlias) {
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            } else {
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED
            }

            try {
                val cn = ComponentName(pkg, "$pkg.$alias")
                // যদি আগে থেকেই একই স্টেটে থাকে, তবে বারবার কমান্ড না পাঠানো
                if (pm.getComponentEnabledSetting(cn) != state) {
                    pm.setComponentEnabledSetting(
                        cn,
                        state,
                        PackageManager.DONT_KILL_APP
                    )
                }
            } catch (_: Exception) {
                // ম্যানিফেস্টে কোনো অ্যালিয়াস মিসিং থাকলে অ্যাপ যেন ক্র্যাশ না করে
            }
        }
    }

    /** বর্তমানে কোন আইকনটি অ্যাক্টিভ আছে তা চেক করার ফাংশন */
    fun getCurrentIconAlias(context: Context): String {
        val pm = context.packageManager
        val pkg = context.packageName

        for (alias in allAliases) {
            try {
                val cn = ComponentName(pkg, "$pkg.$alias")
                val state = pm.getComponentEnabledSetting(cn)
                if (state == PackageManager.COMPONENT_ENABLED_STATE_ENABLED) {
                    return alias
                }
            } catch (_: Exception) {}
        }
        return "MainActivityAliasDefault"
    }
}
