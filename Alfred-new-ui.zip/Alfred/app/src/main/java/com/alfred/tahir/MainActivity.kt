@file:OptIn(ExperimentalMaterial3Api::class)

package com.alfred.tahir

import android.Manifest
import android.app.role.RoleManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat

fun isAccessibilityEnabled(ctx: Context): Boolean {
    val enabled = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        ?: return false
    val cn = ComponentName(ctx, AlfredAccessibilityService::class.java)
    return enabled.split(':').any {
        it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true)
    }
}

class MainActivity : ComponentActivity() {

    private val SCREEN_CAST_REQUEST = 1000

    private var accEnabled by mutableStateOf(false)
    private var micOk by mutableStateOf(false)
    private var tick by mutableStateOf(0)

    private val roleLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { refresh() }

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        L.load()
        setContent {
            AlfredTheme {
                Root(
                    accEnabled, 
                    micOk, 
                    tick, 
                    { requestPerms() }, 
                    { requestCallRole() },
                    { askForScreenSharePermission() } // পাসিং লাইভ ভিশন ট্রিগার
                )
            }
        }
        handleToggle(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleToggle(intent)
    }

    /** Quick Settings tile opens the app with toggle=true: switch Alfred on/off, then go back. */
    private fun handleToggle(i: Intent?) {
        if (i?.getBooleanExtra("toggle", false) != true) return
        i.removeExtra("toggle")
        refresh()
        if (!accEnabled) return
        if (AlfredState.running.value) {
            AssistantService.stop(this)
            moveTaskToBack(true)
        } else if (micOk && Prefs.apiKey.isNotBlank() && ModelManager.isReady(this)) {
            AssistantService.start(this)
            moveTaskToBack(true)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        accEnabled = isAccessibilityEnabled(this)
        micOk = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        tick++
    }

    private fun requestCallRole() {
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) {
                roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
            }
        }
    }

    private fun requestPerms() {
        val l = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.READ_PHONE_STATE
        )
        if (Build.VERSION.SDK_INT >= 33) l += Manifest.permission.POST_NOTIFICATIONS
        permLauncher.launch(l.toTypedArray())
    }

    // ==========================================
    // LIVE VISION (MEDIA PROJECTION) SETUP
    // ==========================================

    private fun askForScreenSharePermission() {
        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(projectionManager.createScreenCaptureIntent(), SCREEN_CAST_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == SCREEN_CAST_REQUEST && resultCode == RESULT_OK && data != null) {
            ScreenCastService.resultCode = resultCode
            ScreenCastService.intentData = data
            
            val serviceIntent = Intent(this, ScreenCastService::class.java)
            startForegroundService(serviceIntent)
        }
    }
}

@Composable
fun AlfredTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = UI.Blue,
            onPrimary = UI.OnAccent,
            surface = UI.Panel,
            onSurface = UI.Ink,
            background = UI.Bg,
            onBackground = UI.Ink,
            surfaceVariant = UI.Panel,
            onSurfaceVariant = UI.Sub,
            outline = UI.Blue
        ),
        content = content
    )
}

/**
 * Navigation: a tiny back stack of route names.
 * welcome -> (accessibility gate) -> home | chat | settings | orb | quick | s_* | history
 */
@Composable
fun Root(
    accEnabled: Boolean, 
    micOk: Boolean, 
    tick: Int, 
    requestPerms: () -> Unit, 
    requestRole: () -> Unit,
    onStartLiveVision: () -> Unit
) {
    var onboarded by remember { mutableStateOf(Prefs.onboarded) }
    val stack = remember { mutableStateListOf("home") }
    val route = stack.last()

    fun nav(r: String) {
        if (stack.last() != r) stack.add(r)
    }

    fun back() {
        if (stack.size > 1) stack.removeAt(stack.size - 1)
    }

    fun tab(r: String) {
        stack.clear()
        stack.add("home")
        if (r != "home") stack.add(r)
    }

    BackHandler(enabled = onboarded && accEnabled && stack.size > 1) { back() }

    AlfredBackground {
        when {
            !onboarded -> WelcomeScreen { Prefs.onboarded = true; onboarded = true }
            !accEnabled -> GateScreen()
            else -> when (route) {
                "chat" -> ChatScreen(onBack = { back() }, onHistory = { nav("history") })
                "settings" -> SettingsListScreen(nav = { nav(it) }, onTab = { tab(it) })
                "orb" -> OrbScreen { back() }
                "quick" -> QuickScreen { back() }
                "s_ai" -> AiSettingsScreen { back() }
                "s_voice" -> VoiceSettingsScreen { back() }
                "s_acc" -> AccessibilitySettingsScreen(tick) { back() }
                "s_memory" -> MemorySettingsScreen { back() }
                "s_notif" -> NotificationSettingsScreen(tick) { back() }
                "s_general" -> GeneralSettingsScreen(tick, requestRole, { nav("history") }) { back() }
                "history" -> HistoryScreen { back() }
                // হোম স্ক্রিনে (বা যেখানে অরব আছে) লাইভ ভিশন ট্রিগার ফাংশনটি পাস করা হলো
                else -> HomeScreen(
                    nav = { nav(it) }, 
                    micOk = micOk, 
                    requestPerms = requestPerms,
                    onStartLiveVision = onStartLiveVision
                )
            }
        }
    }
}
