package com.alfred.tahir

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

/** Tiny UI translation table: English / বাংলা / हिन्दी. */
object L {
    var ui by mutableStateOf("auto")

    fun load() { ui = Prefs.uiLang }

    fun set(code: String) {
        ui = code
        Prefs.uiLang = code
    }

    private fun idx(): Int {
        val l = if (ui == "auto") Locale.getDefault().language else ui
        return when (l) { "bn" -> 1; "hi" -> 2; else -> 0 }
    }

    fun s(key: String): String = (T[key] ?: T2[key])?.getOrNull(idx()) ?: key

    private val T: Map<String, List<String>> = mapOf(
        "app_sub" to listOf("Your voice assistant", "আপনার ভয়েস সহকারী", "आपका वॉइस असिस्टेंट"),
        "settings" to listOf("Settings", "সেটিংস", "सेटिंग्स"),
        "back" to listOf("Back", "পিছনে", "वापस"),
        "gate_title" to listOf("Turn on Accessibility", "অ্যাক্সেসিবিলিটি চালু করুন", "एक्सेसिबिलिटी चालू करें"),
        "gate_body" to listOf(
            "Alfred needs the Accessibility service to tap, scroll, type and open apps for you. Without it the app cannot work.",
            "আপনার হয়ে ট্যাপ, স্ক্রল, টাইপ ও অ্যাপ খুলতে Alfred-এর অ্যাক্সেসিবিলিটি সার্ভিস লাগবে। এটি ছাড়া অ্যাপ কাজ করবে না।",
            "आपके लिए टैप, स्क्रॉल, टाइप और ऐप खोलने के लिए Alfred को एक्सेसिबिलिटी सर्विस चाहिए। इसके बिना ऐप काम नहीं करेगा।"
        ),
        "gate_hint" to listOf(
            "Settings → Accessibility → Installed apps → Alfred → turn on. If it is greyed out: long-press the app icon → App info → ⋮ → Allow restricted settings.",
            "সেটিংস → অ্যাক্সেসিবিলিটি → ইনস্টল করা অ্যাপ → Alfred → চালু করুন। ধূসর থাকলে: অ্যাপ আইকন চেপে ধরুন → অ্যাপ তথ্য → ⋮ → সীমাবদ্ধ সেটিংস অনুমতি দিন।",
            "सेटिंग्स → एक्सेसिबिलिटी → इंस्टॉल किए गए ऐप → Alfred → चालू करें। ग्रे दिखे तो: ऐप आइकन दबाए रखें → ऐप जानकारी → ⋮ → प्रतिबंधित सेटिंग्स की अनुमति दें।"
        ),
        "open_acc" to listOf("Open Accessibility settings", "অ্যাক্সেসিবিলিটি সেটিংস খুলুন", "एक्सेसिबिलिटी सेटिंग्स खोलें"),
        "setup" to listOf("Finish setup", "সেটআপ শেষ করুন", "सेटअप पूरा करें"),
        "step_mic" to listOf("Microphone & notification permission", "মাইক্রোফোন ও নোটিফিকেশন অনুমতি", "माइक्रोफ़ोन और नोटिफ़िकेशन अनुमति"),
        "step_key" to listOf("Add your Gemini API key", "আপনার Gemini API key দিন", "अपनी Gemini API key डालें"),
        "step_model" to listOf("Download wake-word model (~40 MB)", "ওয়েক-ওয়ার্ড মডেল ডাউনলোড (~৪০ MB)", "वेक-वर्ड मॉडल डाउनलोड (~40 MB)"),
        "grant" to listOf("Grant", "অনুমতি দিন", "अनुमति दें"),
        "download" to listOf("Download", "ডাউনলোড", "डाउनलोड"),
        "save" to listOf("Save", "সেভ", "सेव"),
        "get_key" to listOf("Get free key", "ফ্রি key নিন", "फ्री key लें"),
        "turn_on" to listOf("Turn on", "চালু করুন", "चालू करें"),
        "turn_off" to listOf("Turn off", "বন্ধ করুন", "बंद करें"),
        "st_off" to listOf("Off", "বন্ধ", "बंद"),
        "st_idle" to listOf("Say “Alfred”…", "বলুন “Alfred”…", "कहिए “Alfred”…"),
        "st_listen" to listOf("Listening…", "শুনছি…", "सुन रहा हूँ…"),
        "st_think" to listOf("Thinking…", "ভাবছি…", "सोच रहा हूँ…"),
        "st_speak" to listOf("Speaking…", "বলছি…", "बोल रहा हूँ…"),
        "hint_orb" to listOf(
            "Tap the orb to talk (tap again to stop) · Long-press to open the app · Drag to move",
            "কথা বলতে অর্বে ট্যাপ করুন · অ্যাপ খুলতে চেপে ধরুন · সরাতে টেনে নিন",
            "बात करने के लिए ऑर्ब पर टैप करें · ऐप खोलने के लिए दबाए रखें · खिसकाने के लिए खींचें"
        ),
        "sec_gemini" to listOf("Gemini", "Gemini", "Gemini"),
        "api_key" to listOf("API key", "API key", "API key"),
        "model" to listOf("Model", "মডেল", "मॉडल"),
        "custom_model" to listOf("Custom model name", "নিজের মডেলের নাম", "अपना मॉडल नाम"),
        "show" to listOf("Show", "দেখান", "दिखाएँ"),
        "hide" to listOf("Hide", "লুকান", "छिपाएँ"),
        "sec_lang" to listOf("Language", "ভাষা", "भाषा"),
        "reply_lang" to listOf("Alfred speaks", "Alfred যে ভাষায় বলবে", "Alfred किस भाषा में बोले"),
        "auto_match" to listOf("Auto (match my voice)", "অটো (আমার ভাষা অনুযায়ী)", "ऑटो (मेरी भाषा के अनुसार)"),
        "ui_lang" to listOf("App language", "অ্যাপের ভাষা", "ऐप की भाषा"),
        "auto" to listOf("Auto", "অটো", "ऑटो"),
        "sec_voice" to listOf("Voice", "কণ্ঠ", "आवाज़"),
        "voice_gemini" to listOf("Gemini voice (male)", "Gemini কণ্ঠ (পুরুষ)", "Gemini आवाज़ (पुरुष)"),
        "voice_phone" to listOf("Phone voice", "ফোনের কণ্ঠ", "फ़ोन की आवाज़"),
        "sec_orb" to listOf("Floating orb", "ভাসমান অর্ব", "फ्लोटिंग ऑर्ब"),
        "orb_show" to listOf("Show orb", "অর্ব দেখান", "ऑर्ब दिखाएँ"),
        "orb_size" to listOf("Size", "আকার", "आकार"),
        "orb_color" to listOf("Color", "রঙ", "रंग"),
        "sec_voice" to listOf("Owner voice guard", "মালিকের কণ্ঠ সুরক্ষা", "मालिक की आवाज़ सुरक्षा"),
        "voice_guard" to listOf("Obey only my voice", "শুধু আমার কণ্ঠের কথা শুনবে", "सिर्फ़ मेरी आवाज़ सुनेगा"),
        "voice_model" to listOf("Download voice model (about 13 MB)", "ভয়েস মডেল ডাউনলোড (প্রায় ১৩ MB)", "वॉइस मॉडल डाउनलोड (लगभग 13 MB)"),
        "voice_train" to listOf("Train my voice", "আমার কণ্ঠ শেখান", "मेरी आवाज़ सिखाएँ"),
        "voice_clear" to listOf("Remove my voice", "আমার কণ্ঠ মুছুন", "मेरी आवाज़ हटाएँ"),
        "voice_need_on" to listOf("Turn Alfred ON first, then tap Train.", "আগে Alfred চালু করুন, তারপর Train চাপুন।", "पहले Alfred चालू करें, फिर Train दबाएँ।"),
        "voice_enrolled" to listOf("Your voice is saved on this phone", "আপনার কণ্ঠ এই ফোনে সেভ আছে", "आपकी आवाज़ इस फ़ोन में सेव है"),
        "voice_not_enrolled" to listOf("No voice saved yet", "এখনও কণ্ঠ সেভ নেই", "अभी आवाज़ सेव नहीं है"),
        "voice_strict" to listOf("Strictness (left = strict, right = relaxed)", "কড়াকড়ি (বামে = কড়া, ডানে = ঢিলা)", "सख़्ती (बाएँ = सख़्त, दाएँ = ढीला)"),
        "voice_score" to listOf("Last match distance (lower = more like you)", "শেষ মিলের দূরত্ব (কম = আপনার মতো)", "आख़िरी मिलान दूरी (कम = आपके जैसा)"),
        "orb_style" to listOf("Character", "চরিত্র", "किरदार"),
        "orb_hue" to listOf("Custom colour (slide to mix)", "নিজের রঙ (স্লাইড করুন)", "अपना रंग (स्लाइड करें)"),
        "orb_opacity" to listOf("Opacity", "স্বচ্ছতা", "पारदर्शिता"),
        "sec_acc" to listOf("Accessibility service", "অ্যাক্সেসিবিলিটি সার্ভিস", "एक्सेसिबिलिटी सर्विस"),
        "acc_on" to listOf("Enabled", "চালু আছে", "चालू है"),
        "acc_off" to listOf("Disabled", "বন্ধ আছে", "बंद है"),
        "history" to listOf("History", "ইতিহাস", "इतिहास"),
        "hist_empty" to listOf("No conversations yet.", "এখনো কোনো কথোপকথন নেই।", "अभी कोई बातचीत नहीं है।"),
        "clear_all" to listOf("Clear all", "সব মুছুন", "सब हटाएँ"),
        "sec_memory" to listOf("Memory & routines", "স্মৃতি ও রুটিন", "याददाश्त और रूटीन"),
        "mem_empty" to listOf("Nothing saved yet.", "এখনো কিছু সেভ হয়নি।", "अभी कुछ सेव नहीं है।"),
        "mem_hint" to listOf(
            "Say: “Alfred, remember …” or teach a routine: “when I say good morning, tell me the time and open YouTube”.",
            "বলুন: “Alfred, মনে রাখো …” অথবা রুটিন শেখান: “আমি good morning বললে সময় বলো আর YouTube খোলো”।",
            "कहिए: “Alfred, याद रखो …” या रूटीन सिखाइए: “जब मैं good morning कहूँ तो समय बताओ और YouTube खोलो”।"
        ),
        "sec_notif" to listOf("Notifications", "নোটিফিকেশন", "नोटिफ़िकेशन"),
        "notif_open" to listOf("Open notification access", "নোটিফিকেশন অ্যাক্সেস খুলুন", "नोटिफ़िकेशन एक्सेस खोलें"),
        "notif_auto" to listOf("Read new notifications aloud", "নতুন নোটিফিকেশন পড়ে শোনাও", "नए नोटिफ़िकेशन पढ़कर सुनाओ"),
        "notif_hint" to listOf(
            "Lets Alfred read your notifications and reply to messages when you ask.",
            "আপনি বললে Alfred নোটিফিকেশন পড়বে এবং মেসেজের উত্তর দিতে পারবে।",
            "आपके कहने पर Alfred नोटिफ़िकेशन पढ़ेगा और मैसेज का जवाब दे सकेगा।"
        ),
        "bubble_show" to listOf("Show text bubble", "লেখার বাবল দেখান", "टेक्स्ट बबल दिखाएँ"),
        "sec_proactive" to listOf("Alfred talks first", "Alfred নিজে থেকে কথা বলবে", "Alfred खुद बात करेगा"),
        "proactive_on" to listOf("Check in on me from time to time", "মাঝে মাঝে নিজে থেকে কথা বলো", "बीच-बीच में खुद बात करो"),
        "proactive_every" to listOf("About every", "প্রায় প্রতি", "लगभग हर"),
        "proactive_from" to listOf("Not before (hour)", "এর আগে নয় (ঘণ্টা)", "इससे पहले नहीं (घंटा)"),
        "proactive_to" to listOf("Not after (hour)", "এর পরে নয় (ঘণ্টা)", "इसके बाद नहीं (घंटा)"),
        "proactive_hint" to listOf(
            "Alfred speaks first only when the screen is on and unlocked, you are not in a call, no music is playing and Do Not Disturb is off. He has no live news: he asks, chats and then does what you say.",
            "স্ক্রিন অন ও আনলক থাকলে, কল বা গান না চললে এবং ডু নট ডিস্টার্ব বন্ধ থাকলে তবেই Alfred আগে কথা বলবে। তার কাছে লাইভ খবর নেই: সে জিজ্ঞেস করবে, গল্প করবে, তারপর তুমি যা বলবে তাই করবে।",
            "स्क्रीन ऑन और अनलॉक हो, कॉल या संगीत न चल रहा हो और डू नॉट डिस्टर्ब बंद हो, तभी Alfred पहले बोलेगा। उसके पास लाइव खबर नहीं है: वह पूछेगा, बातें करेगा, फिर जो आप कहें वही करेगा।"
        ),
        "sec_call" to listOf("Unknown calls (experimental)", "অচেনা কল (পরীক্ষামূলক)", "अनजान कॉल (प्रायोगिक)"),
        "call_role" to listOf("Set Alfred as call screening app", "Alfred কে কল স্ক্রিনিং অ্যাপ করুন", "Alfred को कॉल स्क्रीनिंग ऐप बनाएँ"),
        "call_role_on" to listOf("Alfred is the call screening app", "Alfred এখন কল স্ক্রিনিং অ্যাপ", "Alfred अभी कॉल स्क्रीनिंग ऐप है"),
        "call_auto" to listOf("Alfred answers unknown numbers", "অচেনা নম্বরের কল Alfred ধরবে", "अनजान नंबर का कॉल Alfred उठाएगा"),
        "call_lang" to listOf("Show the call text in", "কলের লেখা যে ভাষায় দেখাবে", "कॉल का टेक्स्ट किस भाषा में दिखाए"),
        "owner_name" to listOf("Your name (for the greeting)", "আপনার নাম (শুভেচ্ছার জন্য)", "आपका नाम (अभिवादन के लिए)"),
        "call_hint" to listOf(
            "Alfred talks through the loudspeaker and listens with the microphone, so this only works if your phone lets the microphone hear the caller. Alfred must be turned ON.",
            "Alfred লাউডস্পিকারে কথা বলে আর মাইকে শোনে, তাই ফোনের মাইক কলারের আওয়াজ ধরলেই কাজ করবে। Alfred চালু থাকতে হবে।",
            "Alfred लाउडस्पीकर से बोलता है और माइक से सुनता है, इसलिए यह तभी चलेगा जब फ़ोन का माइक कॉलर की आवाज़ पकड़े। Alfred चालू होना चाहिए।"
        ),
        "call_unknown" to listOf("Unknown caller", "অচেনা কলার", "अनजान कॉलर"),
        "call_notinc" to listOf("not in contacts", "কন্টাক্টে নেই", "कॉन्टैक्ट में नहीं"),
        "call_answer" to listOf("Let Alfred answer", "Alfred ধরুক", "Alfred उठाए"),
        "call_reject" to listOf("Reject", "কেটে দিন", "काटें"),
        "call_take" to listOf("Take over", "আমি ধরছি", "मैं लेता हूँ"),
        "call_end" to listOf("End call", "কল কাটুন", "कॉल काटें"),
        "call_title" to listOf("Alfred is on the call", "Alfred কলে আছে", "Alfred कॉल पर है"),
        "call_nomic" to listOf(
            "I cannot hear the caller on this phone's microphone - this method may not work here.",
            "এই ফোনের মাইকে কলারের আওয়াজ পাচ্ছি না - এখানে এই পদ্ধতি কাজ নাও করতে পারে।",
            "इस फ़ोन के माइक से कॉलर की आवाज़ नहीं आ रही - यहाँ यह तरीका शायद न चले।"
        ),
        "call_done" to listOf("Call handled.", "কল শেষ।", "कॉल पूरा।"),
        "privacy" to listOf(
            "Your key is stored only on this phone and is sent only to Google's Gemini API.",
            "আপনার key শুধু এই ফোনে থাকে এবং শুধু Google Gemini API-তে যায়।",
            "आपकी key सिर्फ़ इस फ़ोन में रहती है और सिर्फ़ Google Gemini API को भेजी जाती है।"
        )
    )
}
