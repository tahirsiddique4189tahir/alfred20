package com.alfred.tahir.call

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.alfred.tahir.AlfredAccessibilityService
import com.alfred.tahir.AssistantService
import com.alfred.tahir.L

/**
 * Call card shown over the phone app: caller info + live conversation text.
 * Uses the accessibility overlay window, so no "display over other apps" permission is needed.
 */
object CallOverlay {
    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var root: LinearLayout? = null
    private var tv: TextView? = null
    private var sv: ScrollView? = null
    private val lines = SpannableStringBuilder()
    private var hideTask: Runnable? = null

    /** Removes the card after [ms] (a newer card cancels this timer). */
    fun hideAfter(ms: Long) {
        main.post {
            hideTask?.let { main.removeCallbacks(it) }
            val t = Runnable { remove() }
            hideTask = t
            main.postDelayed(t, ms)
        }
    }

    /** handling=false: incoming unknown call (buttons: let Alfred answer / reject). handling=true: Alfred is talking. */
    fun show(number: String, handling: Boolean) {
        main.post { build(number, handling) }
    }

    fun hide() {
        main.post { remove() }
    }

    fun addLine(who: String, text: String) {
        main.post {
            val color = when (who) {
                "Caller" -> 0xFFFFEB3B.toInt()
                "Alfred" -> 0xFF00E676.toInt()
                else -> 0xFF9AA0A6.toInt()
            }
            val start = lines.length
            lines.append(who).append(": ").append(text).append('\n')
            lines.setSpan(ForegroundColorSpan(color), start, start + who.length + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            tv?.text = lines
            sv?.post { sv?.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun remove() {
        try { root?.let { wm?.removeView(it) } } catch (_: Exception) {}
        root = null
        tv = null
        sv = null
    }

    private fun build(number: String, handling: Boolean) {
        hideTask?.let { main.removeCallbacks(it) }
        hideTask = null
        val svc = AlfredAccessibilityService.instance ?: return
        remove()
        if (!handling) lines.clear()
        val manager = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm = manager
        val d = svc.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val box = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(14))
            background = GradientDrawable().apply {
                setColor(0xEE14121F.toInt())
                cornerRadius = dp(24).toFloat()
            }
        }
        box.addView(TextView(svc).apply {
            text = if (handling) L.s("call_title") else L.s("call_unknown")
            setTextColor(0xFF00E676.toInt())
            textSize = 18f
        })
        box.addView(TextView(svc).apply {
            text = (if (number.isBlank()) "?" else number) + "  \u2022  " + L.s("call_notinc")
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 14f
            setPadding(0, dp(4), 0, dp(8))
        })

        if (handling) {
            val t = TextView(svc).apply {
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 15f
                text = lines
            }
            val s = ScrollView(svc)
            s.addView(t)
            box.addView(s, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(220)))
            tv = t
            sv = s
        }

        val row = LinearLayout(svc).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, 0)
        }
        fun btn(label: String, color: Int, onClick: () -> Unit): Button = Button(svc).apply {
            text = label
            setTextColor(0xFFFFFFFF.toInt())
            isAllCaps = false
            background = GradientDrawable().apply { setColor(color); cornerRadius = dp(20).toFloat() }
            setOnClickListener { onClick() }
            val p = LinearLayout.LayoutParams(0, dp(46), 1f)
            p.setMargins(dp(4), 0, dp(4), 0)
            layoutParams = p
        }
        val appCtx = svc.applicationContext
        if (handling) {
            row.addView(btn(L.s("call_take"), 0xFF2196F3.toInt()) {
                AssistantService.instance?.interrupt()
                remove()
            })
            row.addView(btn(L.s("call_end"), 0xFFF44336.toInt()) {
                AssistantService.instance?.interrupt()
                CallBridge.reject(appCtx)
                remove()
            })
        } else {
            row.addView(btn(L.s("call_answer"), 0xFF2E7D32.toInt()) { CallBridge.answer(appCtx, number) })
            row.addView(btn(L.s("call_reject"), 0xFFF44336.toInt()) {
                CallBridge.reject(appCtx)
                remove()
            })
            row.addView(btn("\u2715", 0xFF555555.toInt()) { remove() })
        }
        box.addView(row)

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.y = dp(60)
        p.horizontalMargin = 0.03f
        try {
            manager.addView(box, p)
            root = box
        } catch (_: Exception) {
        }
    }
}
