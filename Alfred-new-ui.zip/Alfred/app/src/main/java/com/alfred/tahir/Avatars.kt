package com.alfred.tahir

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import androidx.core.graphics.ColorUtils
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Cute animated characters for the floating orb. Index 0 = the classic glass orb (drawn in OrbView). */
object AvatarStyles {
    val labels = listOf("🔮 Orb", "🐱 Cat", "👻 Ghost", "🤖 Robot", "🟢 Blob", "👽 Alien", "🐰 Bunny", "🫧 Glass")
    val count: Int get() = labels.size
}

/**
 * Draws pseudo-3D characters with plain Canvas (no WebView, no extra library, very light on battery).
 * 3D look = shaded gradients + soft ground shadow + squash/stretch + a small "turn" sway of the face.
 * Every animation uses whole multiples of [phase] (0..1 loop) so the loop never jumps.
 */
class AvatarPainter {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    private val ink = 0xFF2B2B3A.toInt()
    private val pink = 0xFFFF9EB5.toInt()

    private fun mix(a: Int, b: Int, t: Float): Int = ColorUtils.blendARGB(a, b, t)

    // ------------------------------------------------------------------ helpers

    private fun fill(color: Int) {
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = color
    }

    private fun stroke(color: Int, width: Float) {
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = width
        p.color = color
    }

    private fun ballShader(cx: Float, cy: Float, rad: Float, c1: Int, c2: Int) {
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            cx - rad * 0.35f, cy - rad * 0.40f, rad * 1.5f,
            intArrayOf(mix(c1, Color.WHITE, 0.55f), c1, c2),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
    }

    private fun ball(c: Canvas, x: Float, y: Float, rad: Float, c1: Int, c2: Int) {
        ballShader(x, y, rad, c1, c2)
        c.drawCircle(x, y, rad, p)
        p.shader = null
    }

    private fun ovalShaded(c: Canvas, r: RectF, c1: Int, c2: Int) {
        val rad = max(r.width(), r.height()) / 2f
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            r.centerX() - r.width() * 0.18f, r.centerY() - r.height() * 0.22f, rad * 1.45f,
            intArrayOf(mix(c1, Color.WHITE, 0.55f), c1, c2),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        c.drawOval(r, p)
        p.shader = null
    }

    private fun shine(c: Canvas, x: Float, y: Float, w: Float, h: Float) {
        fill(Color.argb(110, 255, 255, 255))
        rect.set(x - w, y - h, x + w, y + h)
        c.drawOval(rect, p)
    }

    // ------------------------------------------------------------------ face parts

    private fun eyes(
        c: Canvas, fx: Float, y: Float, R: Float, status: Orb, phase: Float, t: Float,
        gap: Float = 0.30f, size: Float = 0.12f
    ) {
        val blink = status == Orb.OFF || (phase > 0.90f && phase < 0.95f)
        val er = R * size * (if (status == Orb.LISTENING) 1.18f else 1f)
        val look = if (status == Orb.THINKING) sin(t * 2f) * R * 0.04f else 0f
        for (s in floatArrayOf(-1f, 1f)) {
            val ex = fx + s * R * gap + look
            if (blink) {
                stroke(ink, R * 0.04f)
                c.drawLine(ex - er, y, ex + er, y, p)
            } else {
                fill(ink)
                rect.set(ex - er, y - er * 1.15f, ex + er, y + er * 1.15f)
                c.drawOval(rect, p)
                fill(Color.WHITE)
                c.drawCircle(ex - er * 0.30f, y - er * 0.40f, er * 0.38f, p)
                c.drawCircle(ex + er * 0.30f, y + er * 0.35f, er * 0.18f, p)
            }
        }
    }

    private fun cheeks(c: Canvas, fx: Float, y: Float, R: Float) {
        fill(Color.argb(95, 255, 120, 160))
        c.drawCircle(fx - R * 0.55f, y, R * 0.10f, p)
        c.drawCircle(fx + R * 0.55f, y, R * 0.10f, p)
    }

    private fun mouth(c: Canvas, mx: Float, my: Float, R: Float, status: Orb, t: Float) {
        when (status) {
            Orb.SPEAKING -> {
                val open = 0.5f + 0.5f * sin(t * 6f)
                fill(ink)
                rect.set(mx - R * 0.09f, my - R * 0.02f, mx + R * 0.09f, my + R * (0.04f + 0.15f * open))
                c.drawOval(rect, p)
                fill(pink)
                rect.set(mx - R * 0.05f, my + R * (0.05f + 0.07f * open), mx + R * 0.05f, my + R * (0.04f + 0.15f * open))
                c.drawOval(rect, p)
            }
            Orb.LISTENING -> {
                fill(ink)
                c.drawCircle(mx, my + R * 0.03f, R * 0.055f, p)
            }
            Orb.THINKING -> {
                stroke(ink, R * 0.045f)
                c.drawLine(mx - R * 0.07f, my + R * 0.02f, mx + R * 0.09f, my, p)
            }
            else -> {
                stroke(ink, R * 0.045f)
                path.reset()
                path.moveTo(mx - R * 0.12f, my)
                path.quadTo(mx, my + R * 0.14f, mx + R * 0.12f, my)
                c.drawPath(path, p)
            }
        }
    }

    // ------------------------------------------------------------------ main entry

    fun draw(c: Canvas, style: Int, w: Float, h: Float, status: Orb, phase: Float, c1: Int, c2: Int) {
        val u = min(w, h) / 2f
        val cx = w / 2f
        val cy = h / 2f + 0.08f * u
        val t = (2.0 * PI * phase).toFloat()

        val fast = when (status) {
            Orb.SPEAKING -> 3
            Orb.THINKING -> 2
            Orb.LISTENING -> 2
            else -> 1
        }
        val amp = when (status) {
            Orb.OFF -> 0.008f
            Orb.IDLE -> 0.030f
            Orb.LISTENING -> 0.035f
            Orb.THINKING -> 0.020f
            Orb.SPEAKING -> 0.050f
        }
        val bob = sin(t * fast) * u * amp
        val sway = sin(t)
        val sq = 1f + 0.035f * sin(t * fast * 2)

        // soft glow behind
        if (status != Orb.OFF) {
            p.style = Paint.Style.FILL
            p.shader = RadialGradient(
                cx, cy, u * 0.98f,
                intArrayOf(ColorUtils.setAlphaComponent(c2, 85), ColorUtils.setAlphaComponent(c2, 0)),
                floatArrayOf(0.35f, 1f), Shader.TileMode.CLAMP
            )
            c.drawCircle(cx, cy, u * 0.98f, p)
            p.shader = null
        }

        // ripple while listening / speaking
        if (status == Orb.LISTENING || status == Orb.SPEAKING) {
            stroke(ColorUtils.setAlphaComponent(c1, ((1f - phase) * 150).toInt()), u * 0.03f)
            c.drawCircle(cx, cy, u * (0.55f + 0.40f * phase), p)
        }

        // ground shadow (gets smaller when the character is up)
        val sw = u * 0.42f * (1f + bob / u * 3f)
        fill(Color.argb(60, 0, 0, 0))
        rect.set(cx - sw, cy + u * 0.56f, cx + sw, cy + u * 0.66f)
        c.drawOval(rect, p)

        // character
        c.save()
        c.translate(0f, bob)
        c.scale(1f / sq, sq, cx, cy + u * 0.5f)
        when (style) {
            1 -> cat(c, cx, cy, u, status, phase, t, sway, c1, c2)
            2 -> ghost(c, cx, cy, u, status, phase, t, sway, c1, c2)
            3 -> robot(c, cx, cy, u, status, phase, t, sway, c1, c2)
            4 -> blob(c, cx, cy, u, status, phase, t, sway, c1, c2)
            5 -> alien(c, cx, cy, u, status, phase, t, sway, c1, c2)
            6 -> bunny(c, cx, cy, u, status, phase, t, sway, c1, c2)
            7 -> glass(c, cx, cy, u, status, phase, t, sway, c1, c2)
        }
        c.restore()

        // thinking bubbles
        if (status == Orb.THINKING) {
            fill(Color.argb(230, 255, 255, 255))
            for (i in 0..2) {
                val k = 0.5f + 0.5f * sin(t * 2f - i * 1.1f)
                val rr = u * (0.035f + 0.025f * i) * (0.8f + 0.4f * k)
                c.drawCircle(cx + u * (0.42f + 0.13f * i), cy - u * (0.45f + 0.10f * i), rr, p)
            }
        }
        p.shader = null
    }

    // ------------------------------------------------------------------ characters

    private fun cat(c: Canvas, cx: Float, cy: Float, u: Float, st: Orb, ph: Float, t: Float, sway: Float, c1: Int, c2: Int) {
        val R = 0.50f * u
        val twitch = if (st == Orb.LISTENING) sin(t * 4f) * R * 0.06f else sin(t) * R * 0.02f
        val earColor = mix(c1, c2, 0.55f)
        for (s in floatArrayOf(-1f, 1f)) {
            val ex = cx + s * R * 0.58f
            val ey = cy - R * 0.62f
            val tipX = ex + s * R * 0.10f + twitch * s
            val tipY = ey - R * 0.46f
            fill(earColor)
            path.reset()
            path.moveTo(ex - R * 0.32f, ey + R * 0.32f)
            path.lineTo(tipX, tipY)
            path.lineTo(ex + R * 0.32f, ey + R * 0.32f)
            path.close()
            c.drawPath(path, p)
            fill(pink)
            path.reset()
            path.moveTo(ex - R * 0.17f, ey + R * 0.28f)
            path.lineTo(tipX, tipY + R * 0.22f)
            path.lineTo(ex + R * 0.17f, ey + R * 0.28f)
            path.close()
            c.drawPath(path, p)
        }
        ball(c, cx, cy, R, c1, c2)
        shine(c, cx - R * 0.38f, cy - R * 0.55f, R * 0.20f, R * 0.10f)
        val fx = cx + sway * R * 0.10f
        val ey = cy + R * 0.02f
        eyes(c, fx, ey, R, st, ph, t)
        cheeks(c, fx, ey + R * 0.20f, R)
        // nose + whiskers
        fill(pink)
        path.reset()
        path.moveTo(fx - R * 0.06f, ey + R * 0.15f)
        path.lineTo(fx + R * 0.06f, ey + R * 0.15f)
        path.lineTo(fx, ey + R * 0.23f)
        path.close()
        c.drawPath(path, p)
        mouth(c, fx, ey + R * 0.30f, R * 0.85f, st, t)
        stroke(Color.argb(200, 255, 255, 255), R * 0.025f)
        for (s in floatArrayOf(-1f, 1f)) {
            for (k in -1..1) {
                c.drawLine(fx + s * R * 0.38f, ey + R * 0.24f + k * R * 0.05f,
                    fx + s * R * 0.80f, ey + R * 0.20f + k * R * 0.11f, p)
            }
        }
    }

    private fun ghost(c: Canvas, cx: Float, cy: Float, u: Float, st: Orb, ph: Float, t: Float, sway: Float, c1: Int, c2: Int) {
        val R = 0.50f * u
        val body = mix(c1, Color.WHITE, 0.35f)
        val bottom = cy + R * 0.60f
        path.reset()
        path.moveTo(cx - R, bottom)
        path.lineTo(cx - R, cy)
        rect.set(cx - R, cy - R, cx + R, cy + R)
        path.arcTo(rect, 180f, 180f, false)
        path.lineTo(cx + R, bottom)
        val n = 4
        val wv = 2f * R / n
        for (i in 0 until n) {
            val x0 = cx + R - i * wv
            val x1 = x0 - wv
            val dir = if (i % 2 == 0) 1f else -1f
            path.quadTo((x0 + x1) / 2f, bottom + dir * R * 0.26f + sin(t + i) * R * 0.06f, x1, bottom)
        }
        path.close()
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            cx - R * 0.35f, cy - R * 0.5f, R * 2.0f,
            intArrayOf(mix(body, Color.WHITE, 0.6f), body, c2),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawPath(path, p)
        p.shader = null
        // little arms
        val armWave = sin(t * 2f) * R * 0.08f
        fill(mix(body, c2, 0.25f))
        rect.set(cx - R * 1.18f, cy + R * 0.12f + armWave, cx - R * 0.80f, cy + R * 0.36f + armWave)
        c.drawOval(rect, p)
        rect.set(cx + R * 0.80f, cy + R * 0.12f - armWave, cx + R * 1.18f, cy + R * 0.36f - armWave)
        c.drawOval(rect, p)
        shine(c, cx - R * 0.42f, cy - R * 0.62f, R * 0.20f, R * 0.10f)
        val fx = cx + sway * R * 0.10f
        val ey = cy - R * 0.05f
        eyes(c, fx, ey, R, st, ph, t, gap = 0.32f, size = 0.13f)
        cheeks(c, fx, ey + R * 0.22f, R)
        mouth(c, fx, ey + R * 0.30f, R, st, t)
    }

    private fun robot(c: Canvas, cx: Float, cy: Float, u: Float, st: Orb, ph: Float, t: Float, sway: Float, c1: Int, c2: Int) {
        val R = 0.50f * u
        val hw = R * 0.96f
        val hh = R * 0.78f
        val by = cy
        // antenna
        stroke(mix(c2, ink, 0.35f), R * 0.05f)
        val tipX = cx + sway * R * 0.05f
        val tipY = by - hh - R * 0.32f
        c.drawLine(cx, by - hh, tipX, tipY, p)
        val lamp = when (st) {
            Orb.LISTENING -> 0xFF7CF5C0.toInt()
            Orb.THINKING -> 0xFFFFC94D.toInt()
            Orb.SPEAKING -> mix(c1, Color.WHITE, 0.4f)
            else -> c1
        }
        val lampPulse = 0.85f + 0.15f * sin(t * 2f)
        ball(c, tipX, tipY, R * 0.12f * lampPulse, mix(lamp, Color.WHITE, 0.3f), lamp)
        // ear bolts
        ball(c, cx - hw, by, R * 0.14f, mix(c2, Color.WHITE, 0.2f), mix(c2, ink, 0.3f))
        ball(c, cx + hw, by, R * 0.14f, mix(c2, Color.WHITE, 0.2f), mix(c2, ink, 0.3f))
        // head
        rect.set(cx - hw, by - hh, cx + hw, by + hh)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            cx - hw, by - hh, cx + hw * 0.8f, by + hh,
            intArrayOf(mix(c1, Color.WHITE, 0.55f), c1, c2),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(rect, R * 0.36f, R * 0.36f, p)
        p.shader = null
        // face plate
        fill(Color.argb(238, 30, 32, 48))
        rect.set(cx - hw * 0.80f, by - hh * 0.62f, cx + hw * 0.80f, by + hh * 0.66f)
        c.drawRoundRect(rect, R * 0.24f, R * 0.24f, p)
        // eyes
        val fx = cx + sway * R * 0.07f
        val eyeC = mix(c1, Color.WHITE, 0.55f)
        val blink = st == Orb.OFF || (ph > 0.90f && ph < 0.95f)
        val eh = if (blink) R * 0.03f else R * (if (st == Orb.LISTENING) 0.17f else 0.13f)
        for (s in floatArrayOf(-1f, 1f)) {
            val ex = fx + s * R * 0.38f
            val ey = by - hh * 0.14f
            fill(ColorUtils.setAlphaComponent(eyeC, 70))
            rect.set(ex - R * 0.20f, ey - eh * 1.5f, ex + R * 0.20f, ey + eh * 1.5f)
            c.drawRoundRect(rect, R * 0.12f, R * 0.12f, p)
            fill(eyeC)
            rect.set(ex - R * 0.15f, ey - eh, ex + R * 0.15f, ey + eh)
            c.drawRoundRect(rect, R * 0.09f, R * 0.09f, p)
        }
        // speaker-grill mouth
        val base = by + hh * 0.40f
        for (i in -2..2) {
            val bh = if (st == Orb.SPEAKING) R * (0.04f + 0.13f * (0.5f + 0.5f * sin(t * 6f + i * 1.3f))) else R * 0.06f
            fill(eyeC)
            rect.set(fx + i * R * 0.14f - R * 0.04f, base - bh, fx + i * R * 0.14f + R * 0.04f, base + bh)
            c.drawRoundRect(rect, R * 0.03f, R * 0.03f, p)
        }
        shine(c, cx - hw * 0.62f, by - hh * 0.86f, R * 0.30f, R * 0.07f)
    }

    private fun glass(c: Canvas, cx: Float, cy: Float, u: Float, st: Orb, ph: Float, t: Float, sway: Float, c1: Int, c2: Int) {
        val R = 0.52f * u
        val a = mix(c1, Color.WHITE, 0.70f)
        val b = mix(c2, Color.WHITE, 0.55f)
        ball(c, cx, cy, R, a, b)
        stroke(Color.argb(120, 255, 255, 255), R * 0.03f)
        c.drawCircle(cx, cy, R * 0.97f, p)
        shine(c, cx - R * 0.38f, cy - R * 0.50f, R * 0.26f, R * 0.12f)
        val fx = cx + sway * R * 0.08f
        eyes(c, fx, cy - R * 0.04f, R, st, ph, t, gap = 0.34f, size = 0.12f)
        cheeks(c, fx, cy + R * 0.20f, R)
        mouth(c, fx, cy + R * 0.26f, R, st, t)
    }

    private fun blob(c: Canvas, cx: Float, cy: Float, u: Float, st: Orb, ph: Float, t: Float, sway: Float, c1: Int, c2: Int) {
        val R = 0.50f * u
        val wob = sin(t * 2f) * 0.045f
        val rx = R * 1.10f * (1f + wob)
        val ry = R * 0.90f * (1f - wob)
        val by = cy + R * 0.12f
        // top bubble
        ball(c, cx + sway * R * 0.05f, by - ry - R * 0.04f, R * 0.15f, c1, c2)
        rect.set(cx - rx, by - ry, cx + rx, by + ry)
        ovalShaded(c, rect, c1, c2)
        shine(c, cx - rx * 0.45f, by - ry * 0.55f, R * 0.22f, R * 0.11f)
        val fx = cx + sway * R * 0.10f
        val ey = by - R * 0.02f
        eyes(c, fx, ey, R, st, ph, t, gap = 0.34f, size = 0.13f)
        cheeks(c, fx, ey + R * 0.22f, R * 1.05f)
        mouth(c, fx, ey + R * 0.28f, R, st, t)
    }

    private fun alien(c: Canvas, cx: Float, cy: Float, u: Float, st: Orb, ph: Float, t: Float, sway: Float, c1: Int, c2: Int) {
        val R = 0.50f * u
        val rx = R * 0.88f
        val ry = R * 1.00f
        val fx = cx + sway * R * 0.08f
        // antennae
        for (s in floatArrayOf(-1f, 1f)) {
            val ax = cx + s * R * 0.30f
            val tx = cx + s * R * 0.58f + sin(t + s) * R * 0.05f
            val ty = cy - ry - R * 0.30f
            stroke(mix(c2, ink, 0.3f), R * 0.04f)
            c.drawLine(ax, cy - ry * 0.85f, tx, ty, p)
            ball(c, tx, ty, R * 0.10f, Color.WHITE, mix(c1, Color.WHITE, 0.3f))
        }
        rect.set(cx - rx, cy - ry, cx + rx, cy + ry)
        ovalShaded(c, rect, c1, c2)
        shine(c, cx - rx * 0.42f, cy - ry * 0.62f, R * 0.18f, R * 0.09f)
        // big slanted eyes
        val blink = st == Orb.OFF || (ph > 0.90f && ph < 0.95f)
        val big = if (st == Orb.LISTENING) 1.15f else 1f
        for (s in floatArrayOf(-1f, 1f)) {
            val ex = fx + s * R * 0.38f
            val ey = cy - R * 0.02f
            c.save()
            c.rotate(-s * 20f, ex, ey)
            fill(0xFF11111A.toInt())
            val eh = if (blink) R * 0.03f else R * 0.30f * big
            rect.set(ex - R * 0.25f * big, ey - eh, ex + R * 0.25f * big, ey + eh)
            c.drawOval(rect, p)
            if (!blink) {
                fill(Color.WHITE)
                c.drawCircle(ex - R * 0.08f, ey - R * 0.10f, R * 0.07f, p)
                c.drawCircle(ex + R * 0.07f, ey + R * 0.09f, R * 0.03f, p)
            }
            c.restore()
        }
        mouth(c, fx, cy + R * 0.50f, R * 0.8f, st, t)
    }

    private fun bunny(c: Canvas, cx: Float, cy: Float, u: Float, st: Orb, ph: Float, t: Float, sway: Float, c1: Int, c2: Int) {
        val R = 0.50f * u
        val body = mix(c1, Color.WHITE, 0.25f)
        val perk = if (st == Orb.LISTENING) 0f else sin(t) * 6f
        for (s in floatArrayOf(-1f, 1f)) {
            val px = cx + s * R * 0.40f
            val py = cy - R * 0.45f
            c.save()
            c.rotate(s * (8f + perk * 0.6f), px, py)
            rect.set(px - R * 0.17f, py - R * 1.05f, px + R * 0.17f, py + R * 0.05f)
            ovalShaded(c, rect, body, c2)
            fill(pink)
            rect.set(px - R * 0.09f, py - R * 0.88f, px + R * 0.09f, py - R * 0.08f)
            c.drawOval(rect, p)
            c.restore()
        }
        ball(c, cx, cy, R, body, c2)
        shine(c, cx - R * 0.38f, cy - R * 0.55f, R * 0.20f, R * 0.10f)
        val fx = cx + sway * R * 0.10f
        val ey = cy + R * 0.02f
        eyes(c, fx, ey, R, st, ph, t)
        cheeks(c, fx, ey + R * 0.20f, R)
        // teeth first, mouth on top
        fill(Color.WHITE)
        rect.set(fx - R * 0.07f, ey + R * 0.30f, fx + R * 0.07f, ey + R * 0.46f)
        c.drawRoundRect(rect, R * 0.03f, R * 0.03f, p)
        fill(pink)
        c.drawCircle(fx, ey + R * 0.15f, R * 0.06f, p)
        mouth(c, fx, ey + R * 0.28f, R * 0.85f, st, t)
    }
}
