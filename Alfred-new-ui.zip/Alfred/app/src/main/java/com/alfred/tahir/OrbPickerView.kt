package com.alfred.tahir

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Choose kora style / colour / icon save kore rakhe */
object OrbPrefs {
    private fun sp(c: Context) = c.getSharedPreferences("orb_prefs", Context.MODE_PRIVATE)
    fun style(c: Context) = sp(c).getInt("style", 0)
    fun palette(c: Context) = sp(c).getInt("palette", 0)
    fun appIcon(c: Context) = sp(c).getString("app_icon", "MainActivityAliasDefault") ?: "MainActivityAliasDefault"

    fun saveStyle(c: Context, v: Int) = sp(c).edit().putInt("style", v).apply()
    fun savePalette(c: Context, v: Int) = sp(c).edit().putInt("palette", v).apply()
    fun saveAppIcon(c: Context, alias: String) = sp(c).edit().putString("app_icon", alias).apply()
}

/**
 * Shob design er niche ekta Tick Box. Tick dile oi design set hoy.
 * Ekbare ekta style ar ekta colour select thake.
 * Niche "Apply as App Icon" button thakbe dynamic icon change korar jonno.
 */
class OrbPickerView(context: Context) : ScrollView(context) {

    var onStyleSelected: ((Int) -> Unit)? = null
    var onPaletteSelected: ((Int) -> Unit)? = null

    private val styleBoxes = HashMap<Int, CheckBox>()
    private val paletteBoxes = HashMap<Int, CheckBox>()
    private val styleOrbs = ArrayList<OrbView>()
    private var busy = false

    private var currentStyleId = 0
    private var currentPaletteId = 0

    private val root = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(12), dp(12), dp(12), dp(28))
    }

    init {
        setBackgroundColor(0xFF0B1030.toInt())
        addView(root, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        // 1. Dynamic App Icon Changer Section (Top Card)
        addAppIconSection()

        // 2. Orb Palettes & Styles Sections
        section("11 Color Palette", List(OrbStyles.paletteNames.size) { OrbStyles.Item(it, "$it. ${OrbStyles.paletteNames[it]}") }, true)
        section("Classic", OrbStyles.classic, false)
        section("Creative Orb Designs", OrbStyles.creative, false)
        section("Character Style", OrbStyles.characters, false)
        if (OrbStyles.LEGACY_CHAR_COUNT > 0) {
            section("Old Characters", List(OrbStyles.LEGACY_CHAR_COUNT) { OrbStyles.Item(it + 1, "Old ${it + 1}") }, false)
        }
        section("Premium Styles", OrbStyles.premium, false)
        
        setSelection(OrbPrefs.style(context), OrbPrefs.palette(context))
    }

    /** টেলিগ্রামের মতো অ্যাপ আইকন চেঞ্জ করার বাটন সেকশন */
    private fun addAppIconSection() {
        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply {
                setColor(0xFF171F4E.toInt())
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), 0xFF3D4B8C.toInt())
            }
            layoutParams = LinearLayout.LayoutParams(
                LayoutParams.MATCH_PARENT,
                LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(10)
            }
        }

        val title = TextView(context).apply {
            text = "Dynamic App Icon"
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
        }

        val desc = TextView(context).apply {
            text = "নিচের যেকোনো একটি অরব সিলেক্ট করে অ্যাপের আইকন হিসেবে সেট করুন।"
            setTextColor(0xFFB5C0FF.toInt())
            textSize = 12f
            setPadding(0, dp(4), 0, dp(12))
        }

        val btnRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val applyBtn = Button(context).apply {
            text = "✨ Apply as App Icon"
            isAllCaps = false
            setTextColor(Color.WHITE)
            textSize = 13f
            background = GradientDrawable().apply {
                setColor(0xFF6C5CE7.toInt())
                cornerRadius = dp(10).toFloat()
            }
            setOnClickListener {
                val alias = getAliasForStyle(currentStyleId)
                IconHelper.changeAppIcon(context, alias)
                OrbPrefs.saveAppIcon(context, alias)
                Toast.makeText(context, "অ্যাপ আইকন আপডেট হয়েছে! হোমস্ক্রিন চেক করুন।", Toast.LENGTH_SHORT).show()
            }
        }

        val resetBtn = Button(context).apply {
            text = "Reset"
            isAllCaps = false
            setTextColor(0xFFDDE2FF.toInt())
            textSize = 13f
            background = GradientDrawable().apply {
                setColor(0xFF2B356E.toInt())
                cornerRadius = dp(10).toFloat()
            }
            setOnClickListener {
                IconHelper.changeAppIcon(context, "MainActivityAliasDefault")
                OrbPrefs.saveAppIcon(context, "MainActivityAliasDefault")
                Toast.makeText(context, "ডিফল্ট আইকন সেট করা হয়েছে।", Toast.LENGTH_SHORT).show()
            }
        }

        btnRow.addView(applyBtn, LinearLayout.LayoutParams(0, dp(42), 1.6f).apply { rightMargin = dp(8) })
        btnRow.addView(resetBtn, LinearLayout.LayoutParams(0, dp(42), 0.8f))

        card.addView(title)
        card.addView(desc)
        card.addView(btnRow)
        root.addView(card)
    }

    /** 
     * সিলেক্ট করা অরব স্টাইল অনুযায়ী Manifest-এর Activity-Alias নাম রিটার্ন করে।
     * আপনার Manifest-এ যে নামগুলো আছে সেগুলোর সাথে এটি মিলিয়ে দেওয়া হয়েছে।
     */
    private fun getAliasForStyle(styleId: Int): String =
        IconHelper.aliasForStyle(styleId) ?: "MainActivityAliasDefault"

    /** Opener shomoy ager save kora style/colour e tick boshate */
    fun setSelection(style: Int, palette: Int) {
        selectPalette(palette, false)
        selectStyle(style, false)
    }

    private fun selectStyle(id: Int, notify: Boolean) {
        currentStyleId = id
        busy = true
        styleBoxes.forEach { (k, b) -> b.isChecked = (k == id) }
        busy = false
        OrbPrefs.saveStyle(context, id)
        if (notify) onStyleSelected?.invoke(id)
    }

    private fun selectPalette(id: Int, notify: Boolean) {
        currentPaletteId = id
        busy = true
        paletteBoxes.forEach { (k, b) -> b.isChecked = (k == id) }
        busy = false
        styleOrbs.forEach { it.paletteIndex = id }
        OrbPrefs.savePalette(context, id)
        if (notify) onPaletteSelected?.invoke(id)
    }

    private fun section(title: String, items: List<OrbStyles.Item>, palette: Boolean) {
        root.addView(TextView(context).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(4), dp(18), 0, dp(8))
        })
        var row: LinearLayout? = null
        items.forEachIndexed { i, item ->
            if (i % 3 == 0) {
                row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
                root.addView(row)
            }
            row!!.addView(cell(item, palette), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        repeat((3 - items.size % 3) % 3) {
            row!!.addView(View(context), LinearLayout.LayoutParams(0, 1, 1f))
        }
    }

    private fun cell(item: OrbStyles.Item, palette: Boolean): LinearLayout {
        val col = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(6), dp(4), dp(6))
        }
        val orb = OrbView(context).apply {
            status = Orb.IDLE
            if (palette) paletteIndex = item.id else { style = item.id }
        }
        if (!palette) styleOrbs.add(orb)

        val label = TextView(context).apply {
            text = item.name
            setTextColor(0xFFDDE2FF.toInt())
            textSize = 12f
            gravity = Gravity.CENTER
        }
        val box = CheckBox(context).apply {
            buttonTintList = ColorStateList.valueOf(0xFF8F7BFF.toInt())
        }
        (if (palette) paletteBoxes else styleBoxes)[item.id] = box

        box.setOnCheckedChangeListener { _, checked ->
            if (busy) return@setOnCheckedChangeListener
            if (!checked) { // selected ta untick kora jabe na
                busy = true; box.isChecked = true; busy = false
                return@setOnCheckedChangeListener
            }
            if (palette) selectPalette(item.id, true) else selectStyle(item.id, true)
        }
        orb.onTap = { box.isChecked = true }

        col.addView(orb, LinearLayout.LayoutParams(dp(76), dp(76)))
        col.addView(label)
        col.addView(box)
        return col
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
