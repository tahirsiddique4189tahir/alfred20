package com.alfred.tahir

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationManagerCompat

/** Lets Alfred read (and reply to) notifications. Needs "Notification access". */
class AlfredNotificationListener : NotificationListenerService() {

    companion object {
        private val recent = ArrayList<StatusBarNotification>()

        fun isEnabled(ctx: Context): Boolean =
            NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

        private fun label(ctx: Context, pkg: String): String = try {
            ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }

        private fun title(s: StatusBarNotification) =
            s.notification.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""

        private fun body(s: StatusBarNotification) =
            s.notification.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""

        fun summary(ctx: Context): String {
            synchronized(recent) {
                if (recent.isEmpty()) return "NO_NOTIFICATIONS"
                return recent.take(10).mapIndexed { i, s ->
                    "[$i] ${label(ctx, s.packageName)} | ${title(s)} | ${body(s)}".take(240)
                }.joinToString("\n")
            }
        }

        fun reply(ctx: Context, index: Int, text: String): String {
            val s = synchronized(recent) { recent.getOrNull(index) } ?: return "ERROR: no notification [$index]"
            val action = s.notification.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true }
                ?: return "ERROR: this notification has no reply option"
            val inputs = action.remoteInputs
            val intent = Intent()
            val b = Bundle()
            b.putCharSequence(inputs[0].resultKey, text)
            RemoteInput.addResultsToIntent(inputs, intent, b)
            return try {
                action.actionIntent.send(ctx, 0, intent)
                "OK reply sent"
            } catch (e: Exception) {
                "ERROR: ${e.message}"
            }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName || sbn.isOngoing) return
        if (sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val t = title(sbn)
        val b = body(sbn)
        if (t.isBlank() && b.isBlank()) return
        synchronized(recent) {
            recent.removeAll { it.key == sbn.key }
            recent.add(0, sbn)
            while (recent.size > 20) recent.removeAt(recent.size - 1)
        }
        if (Prefs.readNotifications) {
            AssistantService.instance?.announce("${label(this, sbn.packageName)}: $t. $b")
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        synchronized(recent) { recent.removeAll { it.key == sbn.key } }
    }
}
