package com.alfred.tahir.call

import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.telecom.Call
import android.telecom.CallScreeningService
import com.alfred.tahir.Prefs

/**
 * Sees every incoming call. Alfred never blocks a call by itself: it always lets it through,
 * then (for numbers that are not in your contacts) shows an info card and, if you enabled it,
 * answers the call and talks to the caller.
 */
class CallScreenService : CallScreeningService() {

    override fun onScreenCall(callDetails: Call.Details) {
        // always respond quickly, otherwise Android delays the ring
        respondToCall(callDetails, CallResponse.Builder().build())

        if (Build.VERSION.SDK_INT >= 29 && callDetails.callDirection != Call.Details.DIRECTION_INCOMING) return

        // handle can be null for hidden / private numbers: those are exactly the unknown ones
        val number = callDetails.handle?.schemeSpecificPart ?: ""
        if (number.isNotBlank() && isContact(number)) return

        CallOverlay.show(number, false)
        CallOverlay.hideAfter(60000) // the card clears itself if you ignore it
        if (Prefs.callAssist) {
            val ctx = applicationContext
            Handler(Looper.getMainLooper()).postDelayed({ CallBridge.answer(ctx, number) }, 2000)
        }
    }

    private fun isContact(number: String): Boolean {
        return try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
                ?.use { it.moveToFirst() } ?: false
        } catch (e: SecurityException) {
            false // no contacts permission: treat as unknown
        }
    }
}
