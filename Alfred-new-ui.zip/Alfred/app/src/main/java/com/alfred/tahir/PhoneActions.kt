package com.alfred.tahir

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import org.json.JSONObject

/** Direct phone controls (no screen tapping needed). Returns null when the action is not one of these. */
object PhoneActions {

    fun run(ctx: Context, type: String, a: JSONObject): String? = try {
        when (type) {
            "call" -> call(ctx, a)
            "sms" -> sms(ctx, a)
            "alarm" -> alarm(ctx, a)
            "timer" -> timer(ctx, a)
            "flashlight" -> flashlight(ctx, a)
            "volume" -> volume(ctx, a)
            "brightness" -> brightness(ctx, a)
            "set_language" -> {
                val l = a.optString("lang")
                if (l in listOf("auto", "bn", "en", "hi")) Prefs.replyLang = l
                val u = a.optString("ui")
                if (u in listOf("auto", "en", "bn", "hi")) L.set(u)
                "OK language updated"
            }
            "set_voice" -> {
                val n = a.optString("name")
                if (n in Prefs.VOICES) { Prefs.voiceName = n; "OK voice $n" } else "ERROR: unknown voice"
            }
            "set_model" -> {
                val m = a.optString("model")
                if (m.isNotBlank()) { Prefs.model = m; "OK model $m" } else "ERROR: no model"
            }
            "remember" -> { Store.addMemory(a.optString("text")); "OK remembered" }
            "forget" -> "OK forgot ${forget(a.optString("text"))} item(s)"
            "read_notifications" ->
                if (!AlfredNotificationListener.isEnabled(ctx)) {
                    launch(ctx, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    "NEED_PERMISSION: opened Notification access; tell the user to allow Alfred there and ask again"
                } else AlfredNotificationListener.summary(ctx)
            "reply_notification" -> confirmedReply(ctx, a)
            else -> null
        }
    } catch (e: Exception) {
        "ERROR: ${e.message}"
    }

    private var pendingReply: Triple<Int, String, Int>? = null // index, text, turn when requested

    /** A reply is sent only if the same reply was requested in an EARLIER user turn (user said yes). */
    private fun confirmedReply(ctx: Context, a: JSONObject): String {
        val idx = a.optInt("index", -1)
        val text = a.optString("text").trim()
        if (text.isEmpty()) return "ERROR: empty reply text"
        val p = pendingReply
        if (p != null && p.first == idx && p.second == text && AlfredState.turn > p.third) {
            pendingReply = null
            return AlfredNotificationListener.reply(ctx, idx, text)
        }
        pendingReply = Triple(idx, text, AlfredState.turn)
        return "CONFIRM_REQUIRED: not sent. Read this reply to the user, ask 'send it?' (follow_up=true). Send only after they say yes."
    }

    private fun forget(text: String): Int {
        if (text.equals("all", true)) {
            val c = Store.memory().size
            Store.clearMemory()
            return c
        }
        return Store.forgetMemory(text)
    }

    /** Activities are started through the accessibility service (allowed from the background). */
    private fun launch(ctx: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        (AlfredAccessibilityService.instance ?: ctx).startActivity(i)
    }

    private fun queryNumber(ctx: Context, q: String): String? {
        val p = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val cols = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        ctx.contentResolver.query(
            p, cols, "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$q%"), null
        )?.use { c -> if (c.moveToFirst()) return c.getString(1) }
        return null
    }

    private fun findNumber(ctx: Context, name: String): String? {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val q = name.trim()
        if (q.isEmpty()) return null
        queryNumber(ctx, q)?.let { return it }
        for (w in q.split(' ')) if (w.length > 2) queryNumber(ctx, w)?.let { return it }
        return null
    }

    private fun numberOf(ctx: Context, a: JSONObject): String? {
        val n = a.optString("number")
        if (n.isNotBlank()) return n.filter { it.isDigit() || it == '+' }
        val name = a.optString("name")
        return if (name.isBlank()) null else findNumber(ctx, name)
    }

    private fun call(ctx: Context, a: JSONObject): String {
        val num = numberOf(ctx, a)
            ?: return "CONTACT_NOT_FOUND: '${a.optString("name")}' - ask the user for the number (or contacts permission is missing)"
        val granted = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        launch(ctx, Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num))))
        return if (granted) "OK calling $num" else "OK dialer opened with $num (user must press the call button)"
    }

    private fun sms(ctx: Context, a: JSONObject): String {
        val num = numberOf(ctx, a)
            ?: return "CONTACT_NOT_FOUND: '${a.optString("name")}' - ask the user for the number"
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(num)))
        i.putExtra("sms_body", a.optString("text"))
        launch(ctx, i)
        return "OK message app opened for $num with the text ready (not sent yet; tap send after the user confirms)"
    }

    private fun alarm(ctx: Context, a: JSONObject): String {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour", 7).coerceIn(0, 23))
            .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute", 0).coerceIn(0, 59))
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label"))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        launch(ctx, i)
        return "OK alarm set"
    }

    private fun timer(ctx: Context, a: JSONObject): String {
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds", 60).coerceIn(1, 86400))
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label"))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        launch(ctx, i)
        return "OK timer started"
    }

    private fun flashlight(ctx: Context, a: JSONObject): String {
        val cm = ctx.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "ERROR: no flashlight on this phone"
        val on = a.optBoolean("on", true)
        cm.setTorchMode(id, on)
        return "OK flashlight ${if (on) "on" else "off"}"
    }

    private fun volume(ctx: Context, a: JSONObject): String {
        val am = ctx.getSystemService(AudioManager::class.java)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        when {
            a.has("level") -> {
                val v = (a.optInt("level") * max / 100).coerceIn(0, max)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, v, AudioManager.FLAG_SHOW_UI)
            }
            a.optString("direction") == "up" ->
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            a.optString("direction") == "down" ->
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            else -> return "ERROR: give level or direction"
        }
        return "OK volume changed"
    }

    private fun brightness(ctx: Context, a: JSONObject): String {
        val level = a.optInt("level", 50).coerceIn(0, 100)
        if (!Settings.System.canWrite(ctx)) {
            launch(ctx, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            return "NEED_PERMISSION: opened 'Modify system settings'; tell the user to allow Alfred there and ask again"
        }
        Settings.System.putInt(
            ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
        )
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, level * 255 / 100)
        return "OK brightness $level%"
    }
}
