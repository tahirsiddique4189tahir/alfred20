package com.alfred.tahir

import kotlinx.coroutines.flow.MutableStateFlow

data class ChatMsg(val fromUser: Boolean, val text: String, val time: Long = System.currentTimeMillis())

/** Shared live state between services and UI. */
object AlfredState {
    val orb = MutableStateFlow(Orb.OFF)
    val running = MutableStateFlow(false)
    /** -1 = idle, 0..100 = download progress */
    val modelProgress = MutableStateFlow(-1)
    val lastSaid = MutableStateFlow("")
    val error = MutableStateFlow("")
    /** Text shown in the little bubble next to the orb. */
    val bubble = MutableStateFlow("")

    /** owner voice guard: is a voice enrolled, and the last match distance (-1 = none yet) */
    val voiceEnrolled = MutableStateFlow(false)
    val voiceScore = MutableStateFlow(-1f)

    /** Live chat (voice + typed). Newest last. */
    val chat = MutableStateFlow<List<ChatMsg>>(emptyList())
    val chatBusy = MutableStateFlow(false)

    fun addChat(fromUser: Boolean, text: String) {
        if (text.isBlank()) return
        chat.value = (chat.value + ChatMsg(fromUser, text.trim())).takeLast(80)
    }

    /** Counts spoken user turns. Used so risky actions need a NEW user turn to be confirmed. */
    @Volatile
    var turn = 0
}
