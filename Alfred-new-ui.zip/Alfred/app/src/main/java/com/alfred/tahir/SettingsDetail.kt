@file:OptIn(ExperimentalMaterial3Api::class)

package com.alfred.tahir

import android.app.role.RoleManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ------------------------------------------------------------------ AI & Gemini

@Composable
fun AiSettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf(Prefs.apiKey) }
    var showKey by remember { mutableStateOf(false) }
    var model by remember { mutableStateOf(Prefs.model) }

    DetailScaffold(L.s("row_ai"), onBack, L.s("row_ai_s")) {
        GlassCard(L.s("sec_gemini")) {
            OutlinedTextField(
                value = key,
                onValueChange = { key = it; Prefs.apiKey = it },
                label = { Text(L.s("api_key")) },
                singleLine = true,
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    TextButton(onClick = { showKey = !showKey }) {
                        Text(if (showKey) L.s("hide") else L.s("show"), color = UI.Blue)
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )
            TextButton(onClick = {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))
            }) { Text(L.s("get_key"), color = UI.Blue) }
            Spacer(Modifier.height(8.dp))
            Label(L.s("model"))
            Spacer(Modifier.height(6.dp))
            ChipRow(Prefs.MODELS.map { it to it }, model) { model = it; Prefs.model = it }
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = model,
                onValueChange = { model = it; Prefs.model = it },
                label = { Text(L.s("custom_model")) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            Text(L.s("privacy"), color = UI.Sub, fontSize = 12.sp)
        }
    }
}

// ------------------------------------------------------------------ Voice & Language

@Composable
fun VoiceSettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var replyLang by remember { mutableStateOf(Prefs.replyLang) }
    var voiceMode by remember { mutableStateOf(Prefs.voiceMode) }
    var voiceName by remember { mutableStateOf(Prefs.voiceName) }
    var speed by remember { mutableStateOf(Prefs.voiceSpeed) }

    DetailScaffold(L.s("row_voice"), onBack, L.s("row_voice_s")) {
        GlassCard(L.s("sec_lang")) {
            Label(L.s("reply_lang"))
            Spacer(Modifier.height(6.dp))
            ChipRow(
                listOf("auto" to L.s("auto_match"), "bn" to "বাংলা", "en" to "English", "hi" to "हिन्दी"),
                replyLang
            ) { replyLang = it; Prefs.replyLang = it }
            Spacer(Modifier.height(14.dp))
            Label(L.s("ui_lang"))
            Spacer(Modifier.height(6.dp))
            ChipRow(
                listOf("auto" to L.s("auto"), "en" to "English", "bn" to "বাংলা", "hi" to "हिन्दी"),
                L.ui
            ) { L.set(it) }
        }

        GlassCard(L.s("sec_voice")) {
            ChipRow(
                listOf("gemini" to L.s("voice_gemini"), "phone" to L.s("voice_phone")),
                voiceMode
            ) { voiceMode = it; Prefs.voiceMode = it }
            if (voiceMode == "gemini") {
                Spacer(Modifier.height(10.dp))
                ChipRow(Prefs.VOICES.map { it to it }, voiceName) { voiceName = it; Prefs.voiceName = it }
            }
            Spacer(Modifier.height(12.dp))
            Label("Speaking speed")
            Spacer(Modifier.height(6.dp))
            ChipRow(
                listOf("1.0" to "Normal", "1.15" to "Fast", "1.3" to "Faster", "1.5" to "Turbo"),
                listOf(1.0f, 1.15f, 1.3f, 1.5f).minByOrNull { kotlin.math.abs(it - speed) }.toString()
            ) { speed = it.toFloat(); Prefs.voiceSpeed = speed }
        }

        GlassCard(L.s("voice_guard")) {
            val vScope = rememberCoroutineScope()
            val enrolled by AlfredState.voiceEnrolled.collectAsState()
            val score by AlfredState.voiceScore.collectAsState()
            val vRunning by AlfredState.running.collectAsState()
            val vProgress by AlfredState.modelProgress.collectAsState()
            LaunchedEffect(Unit) { AlfredState.voiceEnrolled.value = Prefs.ownerVec.isNotBlank() }
            var spkReady by remember { mutableStateOf(ModelManager.spkReady(ctx)) }
            LaunchedEffect(vProgress) { spkReady = ModelManager.spkReady(ctx) }
            var guardOn by remember { mutableStateOf(Prefs.voiceGuard) }
            var strict by remember { mutableStateOf(Prefs.voiceThreshold) }

            Text(
                if (enrolled) "✓ " + L.s("voice_enrolled") else L.s("voice_not_enrolled"),
                color = if (enrolled) UI.Good else UI.Sub
            )
            Spacer(Modifier.height(8.dp))
            if (!spkReady) {
                SoftButton(L.s("voice_model"), {
                    vScope.launch {
                        ModelManager.downloadSpk(ctx.applicationContext)
                        spkReady = ModelManager.spkReady(ctx)
                    }
                })
                if (vProgress in 0..99) {
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(progress = vProgress / 100f, modifier = Modifier.fillMaxWidth())
                }
            } else {
                SoftButton(L.s("voice_train"), { AssistantService.instance?.requestEnroll() }, enabled = vRunning)
                if (!vRunning) Text(L.s("voice_need_on"), color = UI.Sub, fontSize = 12.sp)
                if (enrolled) {
                    TextButton(onClick = {
                        Prefs.ownerVec = ""
                        Prefs.voiceGuard = false
                        guardOn = false
                        AlfredState.voiceEnrolled.value = false
                    }) { Text(L.s("voice_clear"), color = UI.Bad) }
                }
            }
            Spacer(Modifier.height(6.dp))
            SwitchRow(L.s("voice_guard"), guardOn && enrolled, enabled = enrolled) { guardOn = it; Prefs.voiceGuard = it }
            Label(L.s("voice_strict"))
            Slider(
                value = strict,
                onValueChange = { strict = it; Prefs.voiceThreshold = it },
                valueRange = 0.30f..0.80f,
                colors = sliderColors()
            )
            if (score >= 0f) {
                Label(L.s("voice_score") + ": " + String.format("%.2f", score))
            }
        }
    }
}

// ------------------------------------------------------------------ Accessibility

@Composable
fun AccessibilitySettingsScreen(tick: Int, onBack: () -> Unit) {
    val ctx = LocalContext.current
    DetailScaffold(L.s("row_acc"), onBack, L.s("row_acc_s")) {
        GlassCard(L.s("sec_acc")) {
            val on = remember(tick) { isAccessibilityEnabled(ctx) }
            Text(
                if (on) "✓ " + L.s("acc_on") else L.s("acc_off"),
                color = if (on) UI.Good else UI.Bad, fontWeight = FontWeight.Medium
            )
            Spacer(Modifier.height(10.dp))
            Text(L.s("gate_hint"), color = UI.Sub, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            SoftButton(L.s("open_acc"), { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        }
    }
}

// ------------------------------------------------------------------ Memory

@Composable
fun MemorySettingsScreen(onBack: () -> Unit) {
    var mem by remember { mutableStateOf(Store.memory()) }
    DetailScaffold(L.s("row_mem"), onBack, L.s("row_mem_s")) {
        GlassCard(L.s("sec_memory")) {
            Text(L.s("mem_hint"), color = UI.Sub, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            if (mem.isEmpty()) Text(L.s("mem_empty"), color = UI.Ink)
            mem.forEachIndexed { i, m ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(m, Modifier.weight(1f), color = UI.Ink, fontSize = 14.sp)
                    TextButton(onClick = { Store.removeMemoryAt(i); mem = Store.memory() }) { Text("✕", color = UI.Bad) }
                }
            }
            if (mem.isNotEmpty()) {
                TextButton(onClick = { Store.clearMemory(); mem = emptyList() }) { Text(L.s("clear_all"), color = UI.Bad) }
            }
        }
    }
}

// ------------------------------------------------------------------ Notifications

@Composable
fun NotificationSettingsScreen(tick: Int, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var readNotif by remember { mutableStateOf(Prefs.readNotifications) }
    DetailScaffold(L.s("row_notif"), onBack, L.s("row_notif_s")) {
        GlassCard(L.s("sec_notif")) {
            val nOn = remember(tick) { AlfredNotificationListener.isEnabled(ctx) }
            Text(
                if (nOn) "✓ " + L.s("acc_on") else L.s("acc_off"),
                color = if (nOn) UI.Good else UI.Bad, fontWeight = FontWeight.Medium
            )
            Spacer(Modifier.height(6.dp))
            Text(L.s("notif_hint"), color = UI.Sub, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            SoftButton(L.s("notif_open"), { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) })
            Spacer(Modifier.height(10.dp))
            SwitchRow(L.s("notif_auto"), readNotif) { readNotif = it; Prefs.readNotifications = it }
        }
    }
}

// ------------------------------------------------------------------ General

@Composable
fun GeneralSettingsScreen(tick: Int, requestRole: () -> Unit, onHistory: () -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var orbOn by remember { mutableStateOf(Prefs.orbEnabled) }
    var bubbleOn by remember { mutableStateOf(Prefs.bubbleEnabled) }
    var callAssist by remember { mutableStateOf(Prefs.callAssist) }
    var callLang by remember { mutableStateOf(Prefs.callLang) }
    var ownerName by remember { mutableStateOf(Prefs.ownerName) }
    var proactiveOn by remember { mutableStateOf(Prefs.proactive) }
    var proactiveMins by remember { mutableStateOf(Prefs.proactiveMins) }
    var proactiveFrom by remember { mutableStateOf(Prefs.proactiveFrom) }
    var proactiveTo by remember { mutableStateOf(Prefs.proactiveTo) }

    DetailScaffold(L.s("row_gen"), onBack, L.s("row_gen_s")) {
        GlassCard(L.s("orb_toggle_hint")) {
            SwitchRow(L.s("orb_show"), orbOn) { orbOn = it; Prefs.orbEnabled = it }
            SwitchRow(L.s("bubble_show"), bubbleOn) { bubbleOn = it; Prefs.bubbleEnabled = it }
        }

        GlassCard(L.s("sec_proactive")) {
            SwitchRow(L.s("proactive_on"), proactiveOn) { proactiveOn = it; Prefs.proactive = it }
            if (proactiveOn) {
                Spacer(Modifier.height(8.dp))
                Label(L.s("proactive_every"))
                Spacer(Modifier.height(6.dp))
                ChipRow(
                    listOf("30" to "30 min", "60" to "1 h", "90" to "1.5 h", "180" to "3 h"),
                    proactiveMins.toString()
                ) { proactiveMins = it.toInt(); Prefs.proactiveMins = it.toInt() }
                Spacer(Modifier.height(8.dp))
                Label(L.s("proactive_from"))
                Spacer(Modifier.height(6.dp))
                ChipRow(
                    listOf("7", "8", "9", "10", "11").map { it to "$it:00" },
                    proactiveFrom.toString()
                ) { proactiveFrom = it.toInt(); Prefs.proactiveFrom = it.toInt() }
                Spacer(Modifier.height(8.dp))
                Label(L.s("proactive_to"))
                Spacer(Modifier.height(6.dp))
                ChipRow(
                    listOf("20", "21", "22", "23").map { it to "$it:00" },
                    proactiveTo.toString()
                ) { proactiveTo = it.toInt(); Prefs.proactiveTo = it.toInt() }
                Spacer(Modifier.height(8.dp))
                Text(L.s("proactive_hint"), color = UI.Sub, fontSize = 12.sp)
            }
        }

        GlassCard(L.s("sec_call")) {
            val roleHeld = remember(tick) {
                Build.VERSION.SDK_INT >= 29 &&
                    ctx.getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
            }
            Text(
                if (roleHeld) "✓ " + L.s("call_role_on") else L.s("acc_off"),
                color = if (roleHeld) UI.Good else UI.Bad, fontWeight = FontWeight.Medium
            )
            Spacer(Modifier.height(8.dp))
            SoftButton(L.s("call_role"), requestRole)
            Spacer(Modifier.height(10.dp))
            SwitchRow(L.s("call_auto"), callAssist) { callAssist = it; Prefs.callAssist = it }
            Spacer(Modifier.height(10.dp))
            Label(L.s("call_lang"))
            Spacer(Modifier.height(6.dp))
            ChipRow(
                listOf("bn" to "বাংলা", "en" to "English", "hi" to "हिन्दी"),
                callLang
            ) { callLang = it; Prefs.callLang = it }
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = ownerName,
                onValueChange = { ownerName = it; Prefs.ownerName = it },
                label = { Text(L.s("owner_name")) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            Text(L.s("call_hint"), color = UI.Sub, fontSize = 12.sp)
        }

        GlassCard {
            SoftButton(L.s("open_history"), onHistory)
        }
    }
}

// ------------------------------------------------------------------ History

@Composable
fun HistoryScreen(onBack: () -> Unit) {
    var items by remember { mutableStateOf(Store.history()) }
    val fmt = remember { SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()) }
    DetailScaffold(L.s("history"), onBack) {
        if (items.isNotEmpty()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = { Store.clearHistory(); items = emptyList() }) {
                    Text(L.s("clear_all"), color = UI.Bad)
                }
            }
        }
        if (items.isEmpty()) Text(L.s("hist_empty"), color = UI.Sub)
        items.forEach { h ->
            GlassCard {
                Text(fmt.format(Date(h.time)), color = UI.Sub, fontSize = 12.sp)
                if (h.heard.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text("\u201C" + h.heard + "\u201D", fontWeight = FontWeight.Medium, color = UI.Ink)
                }
                if (h.said.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(h.said, color = UI.Ink)
                }
                if (h.actions.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(h.actions, color = UI.Blue, fontSize = 12.sp)
                }
            }
        }
    }
}
